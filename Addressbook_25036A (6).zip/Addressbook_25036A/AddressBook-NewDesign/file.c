#include <stdio.h>
#include "file.h"

// Void Funtion to save contacts to file 
void saveContactsToFile(AddressBook *addressBook) {
    FILE *ptr = fopen("contacts.csv","w");          //open file it in write mood
    if(ptr == NULL)
    {
        printf("File opened failed\n");             //Check file is opened or not
        return;
    }
    fprintf(ptr, "#%d\n", addressBook->contactCount);       //Print the count of contacts
    for(int i=0;i<addressBook->contactCount;i++)
    {
        fprintf(ptr,"%s, %s, %s\n",addressBook->contacts[i].name,addressBook->contacts[i].phone,addressBook->contacts[i].email); //List the contacts
    }
    fclose(ptr);                        //Close the file 
}

// Function to load contacts from file
void loadContactsFromFile(AddressBook *addressBook) {
    FILE *ptr = fopen("contacts.csv","r");
    if(ptr == NULL)
    {
        addressBook->contactCount = 0;          //check the file condition
        return;
    }
    fscanf(ptr, "#%d\n", &addressBook->contactCount);       //Print the count of contacts along with details
    for(int i=0;i<addressBook->contactCount;i++)
    {
        if (fscanf(ptr,"%49[^,],%14[^,],%49[^\n]\n",addressBook->contacts[i].name,addressBook->contacts[i].phone, addressBook->contacts[i].email) != 3)
            break;
    }
    fclose(ptr);                            //Close the file
} 
