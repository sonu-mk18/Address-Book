#ifndef CONTACT_H
#define CONTACT_H

#define MAX_CONTACTS 100

typedef struct {                //Structure for contacts information
    char name[50];
    char phone[20];
    char email[50];
} Contact;

typedef struct {                //Structure for contacts information
    Contact contacts[100];
    int contactCount;
} AddressBook;

//Function defenitions of all the functions
void createContact(AddressBook *addressBook);
void searchContact(AddressBook *addressBook);
void editContact(AddressBook *addressBook);
void deleteContact(AddressBook *addressBook);
void listContacts(AddressBook *addressBook);
void initialize(AddressBook *addressBook);
void saveContactsToFile(AddressBook *AddressBook);
int search_by_name(AddressBook *addressBook);
int search_by_phone(AddressBook *addressBook);
int search_by_email(AddressBook *addressBook);
int edit_by_name(AddressBook *addressBook,int index);
int edit_by_phone(AddressBook *addressBook,int index);
int edit_by_email(AddressBook *addressBook,int index);


#endif
