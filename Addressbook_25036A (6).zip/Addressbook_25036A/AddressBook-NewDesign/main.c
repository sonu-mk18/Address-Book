/* Shakuntala M K (25036A)
 Project on AddressBook 
 AddressBook is place where you store and manage contact information of people
 Which includes Create contact,Search contact,Ediit contact,Delete contact,List contact,Save and Exit
 Project submmited on 22/01/2026 */

#include <stdio.h>
#include "contact.h"

int main() 
{
    int choice;
    AddressBook addressBook;
    initialize(&addressBook); // Initialize the address book

    do 
    {
        printf("\nAddress Book Menu:\n");
        printf("1. Create contact\n");
        printf("2. Search contact\n");
        printf("3. Edit contact\n");
        printf("4. Delete contact\n");
        printf("5. List all contacts\n");
    	printf("6. Save and Exit\n");		
        printf("7. Exit\n");
        printf("Enter your choice: ");
        scanf(" %d", &choice);
        while (getchar() != '\n');   // clear stdin buffer

        
        switch (choice) 
        {

            case 1:
            {
                createContact(&addressBook);
                break;
            }
            case 2:
                searchContact(&addressBook);
                break;
            case 3:
                editContact(&addressBook);
                break;
            case 4:
                deleteContact(&addressBook);
                break;
            case 5:          
                listContacts(&addressBook);
                break;
            case 6:
                printf("Saving and Exiting...\n");
                saveContactsToFile(&addressBook);
                break;
            default:
                printf("Invalid choice. Please try again.\n");
        }
    } while (choice != 6);
    
    return 0;
}
