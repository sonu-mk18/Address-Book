#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "contact.h"
#include "file.h"
int arr[100] = {0};

//Function to list the contacts 
void listContacts(AddressBook *addressBook) 
{
    // Sort contacts based on the chosen criteria
    int i;
    if(addressBook->contactCount == 0)
    {
        printf("No contacts\n");
        return;
    }
    printf("---------------contacts------------------------\n");        //List the contacts 
    for(int i=0;i<(addressBook->contactCount);i++)
    {
        printf("Contact %d\n",i+1);
        printf("Name:%s\n",addressBook->contacts[i].name);
        printf("Phone number:%s\n",addressBook->contacts[i].phone);
        printf("Email id:%s\n",addressBook->contacts[i].email);
    } 
}

void initialize(AddressBook *addressBook) {
    addressBook->contactCount = 0;
    loadContactsFromFile(addressBook);
}

void saveAndExit(AddressBook *addressBook) {
    saveContactsToFile(addressBook); // Save contacts to file
    exit(EXIT_SUCCESS); // Exit the program
} 

void createContact(AddressBook *addressBook)
{
	// Define the logic to create a Contacts
    Contact newContact;
    int attempts = 3;
    int valid =1;
    do
    {
        printf("Enter name: ");                 //User has to enter the name
        scanf(" %[^\n]", newContact.name);      //Read the name from user
        for(int i = 0; newContact.name[i]; i++)     //Validation for name
        {
            if(!((newContact.name[i] >= 'A' && newContact.name[i] <= 'Z') ||
                (newContact.name[i] >= 'a' && newContact.name[i] <= 'z') ||
                newContact.name[i] == ' ' || newContact.name[i] >= '3'))
            {
                valid = 0;              //Not the valid name
                break;
            }
        }
        if(!valid)
        {
            attempts--;
            printf("Enterd name is not valid,");    //Give the attempts to enter valid name
        }
    } while(!valid && attempts > 0);
    if(attempts == 0)
    {
        printf("Failed to enter valid name.\n");
        return;
    }

    do
    {
        valid = 1;
        printf("Enter phone: ");                //Take the input number from user
        scanf(" %[^\n]", newContact.phone);     //Read the number from user
        if(strlen(newContact.phone) != 10)      //Number should include extact 10 numbers
            valid = 0;
        for(int i = 0; newContact.phone[i] && valid; i++)   //Validate phone number
        {
            if(newContact.phone[0] <'6' || newContact.phone[0] >'9')    //phone number starts with 6 to 9
                valid = 0;

            if(newContact.phone[i] < '0' || newContact.phone[i] > '9')
                valid = 0;
        }
        for(int i = 0; i < addressBook->contactCount && valid; i++)
        {
            if(strcmp(addressBook->contacts[i].phone, newContact.phone) == 0)   //phone number  should be unique
                valid = 0;
        }
        if(!valid)
        {
            attempts--;                                 //give chances to enter valid number
            printf("Entered number is not valid,");
        }
    } while(!valid && attempts > 0);    
    if(attempts == 0)
    {
        printf("Failed to enter valid phone number.\n");
        return;
    }
    
    do
    {
        valid = 1;
        int atCount = 0, atPos = -1, dotPos = -1;
        printf("Enter email id: ");                 //Enter email from user
        scanf(" %[^\n]", newContact.email);         //Read the input from user
        for (int i = 0; newContact.email[i]; i++)   //validate the email id
        {
            if (newContact.email[i] >= 'A' && newContact.email[i] <= 'Z')
            {
                valid = 0;
                break;
            }
            if (newContact.email[i] == '@')
            {
                atCount++;
                atPos = i;
            }
            if (newContact.email[i] == '.')
            {
                dotPos = i;
            }
        }
        if (atCount != 1 || atPos == 0 || dotPos < atPos + 2)
            valid = 0;
        for (int i = 0; i < addressBook->contactCount && valid; i++)
        {
            if (strcmp(addressBook->contacts[i].email, newContact.email) == 0)      //Email id should be unique
                valid = 0;
        }
        if (!valid)
        {
            attempts--;                             //Give chances to enter valid email id
            printf("Entered email is not valid,");
        }
    } while (!valid && attempts > 0);
    if (attempts == 0)
    {
        printf("Failed to enter valid email.\n");
        return;
    }

    addressBook->contacts[addressBook->contactCount] = newContact;      //Update count of contacts to file
    addressBook->contactCount++;                                        //Increse the count of contacts
    printf("\nContact created successfully!\n"); 
} 

//Function to search the contacts
void searchContact(AddressBook *addressBook) 
{
    //Define the logic for search 
    int choice;
    int size = addressBook->contactCount;           //Print the menu to search the contacts
    printf("Menu\n");
    printf("1.Search by name\n");
    printf("2.Search by phone\n");
    printf("3.Search by email\n");
    printf("4.Exit\n");
    printf("Enter the choice:");        
    scanf("%d",&choice);
    switch(choice)
    {
        case 1:
        {
            search_by_name(addressBook);        //Enters to the search by name function
            break;
        }
        case 2:
        {
            search_by_phone(addressBook);       //Enters to the search by phone number
            break;
        }
        case 3:
        {
            search_by_email(addressBook);       //Enters to the search by email id
            break;
        }
        case 4:
        {
            exit(EXIT_SUCCESS);                 //Exit from search function
        }
        default: 
        {
            printf("Contact not found\n");
        }    
    }
    return;
}
int search_by_name(AddressBook *addressBook)        //Search the contact by name
{
    char name[20];
    int index=0;
    int arr[10];
    printf("Enter name:");                      //Take input name from user
    scanf(" %[^\n]",name);                      //Read input name from user
    for(int i=0;i<addressBook->contactCount;i++)
    {
        if(!strcmp(addressBook->contacts[i].name,name))     //Compare the contact with created contact
        {
            arr[index]=i;
            index++;
        }
    }
    if(index == 0)
    {
        printf("Contact not found\n");                  //If no matches found
        return 0;
    }
    for(int i=0;i<index;i++)                            //Check the details
    {
        printf("%d.Name:%s ",i+1,addressBook->contacts[arr[i]].name);
        printf("   Phone:%s ",addressBook->contacts[arr[i]].phone);
        printf("   Email id:%s\n",addressBook->contacts[arr[i]].email);
    }
    int option;
    printf("Enter the option:");
    scanf(" %d",&option);
    if(option < 1 || option > index)
    {
        printf("Invalid option\n");
        return 0;
    }
    printf("Name:%s ",addressBook->contacts[arr[option-1]].name);       //Print the details
    printf("Phone:%s ",addressBook->contacts[arr[option-1]].phone);
    printf("Email:%s\n",addressBook->contacts[arr[option-1]].email);
    return 0; 
}

int search_by_phone(AddressBook *addressBook)       //Search the contact by phone number
{
    char phone[20];
    int found=0;
    printf("Enter phone number:");          //Take input number from user
    scanf(" %[^\n]",phone);                 //Read input from user
    for(int i=0;i<addressBook->contactCount;i++)
    {
        if(!strcmp(addressBook->contacts[i].phone,phone))   //Compare number with contact
        {
            printf("Name:%s ",addressBook->contacts[i].name);       //Print the details
            printf("Phone number:%s ",addressBook->contacts[i].phone);
            printf("Email id:%s\n",addressBook->contacts[i].email);
            found=1;
        }
    }
    if(!found)
    {
        printf("Contact not found\n");      //If no matches found
    }
    return 0;
}

int search_by_email(AddressBook *addressBook)       //Search contact by email id 
{
    char email[50];
    int found=0;
    printf("Enter Emailid:");                       //Take input emailid from user
    scanf(" %[^\n]",email);                         //Read the emailid from user
    for(int i=0;i<addressBook->contactCount;i++)
    {
        if(!strcmp(addressBook->contacts[i].email,email))       //Compare with contacts
        {
            printf("Name:%s ",addressBook->contacts[i].name);   //Print the details 
            printf("Phone number:%s ",addressBook->contacts[i].phone);
            printf("Email id:%s\n",addressBook->contacts[i].email);
            found=1;
        }
    }
    if(!found)
    {
        printf("Contact not found\n");              //If no matches found
    }
    return 0;
} 

//Function to edit the contact
void editContact(AddressBook *addressBook)
{
	// Define the logic for Editcontact 
    int index=0,choice;
    searchContact(addressBook);                 // Call the search function to edit contacts
    if (index == -1)
    {
        printf("Contact not found\n");
        return;
    }
    printf("\nMenu:\n");                        //Prints the menu for edit the contacts
    printf("1.Edit by name\n");
    printf("2.Edit by phone\n");
    printf("3.Edit by email\n");
    printf("4.Exit\n"); 
    printf("Enter the choice:");
    scanf("%d",&choice);
    switch(choice)
    {
        case 1:
        {
            edit_by_name(addressBook, index);       //Enters to edit by name function
            break;
        }
        case 2:
        {
            edit_by_phone(addressBook, index);      //Enters to edit by phone function
            break;
        }
        case 3:
        {
            edit_by_email(addressBook, index);      //Enters to edit by email function
            break;
        }
        case 4:
        {
            exit(EXIT_SUCCESS);                     //Exit from edit function
        }
        default: 
        {
            printf("Contact not found\n");
        }    
    }
    return; 
}

int edit_by_name(AddressBook *addressBook,int index)    //Funtion to edit by name
{
    char name[20];
    int attempts = 3;
    int valid =1;
    do
    {
        printf("Enter name: ");                     //Take input name from user
        scanf(" %[^\n]", name);                     //Read input name from user
        for(int i = 0; name[i]; i++)                //Check the validation for name
        {
            if(!((name[i] >= 'A' && name[i] <= 'Z') ||
                (name[i] >= 'a' && name[i] <= 'z') ||
                name[i] == ' ' || name[i] >= '3'))
            {
                valid = 0;
                break;
            }
        }
        if(!valid)
        {
            attempts--;
            printf("Enterd name is not valid,");        //Give chances to enter valid name
        }
    } while(!valid && attempts > 0);
    if(attempts == 0)
    {
        printf("Failed to enter valid name.\n");
    }
    strcpy(addressBook->contacts[index].name,name);        //Compare and print the details
    printf("\nName :%s",addressBook->contacts[index].name);
    printf("\nphone No :%s",addressBook->contacts[index].phone);
    printf("\nEmail Id :%s\n",addressBook->contacts[index].email); 
    return 0;
}

int edit_by_phone(AddressBook *addressBook,int index)       //Function to edit by phone number
{
    char phone[20];
    int valid = 1;
    int attempts=3;
    do
    {
        printf("Enter phone: ");                            //Take input number from user
        scanf(" %[^\n]", phone);                            //Read input number from user
        if(strlen(phone) != 10)                             //validate phone number
            valid = 0;
        for(int i = 0; phone[i] && valid; i++)
        {
            if(phone[0] <'6' || phone[0] >'9')
                valid = 0;

            if(phone[i] < '0' || phone[i] > '9')
                valid = 0;
        }
        for(int i = 0; i < addressBook->contactCount && valid; i++)
        {
            if(strcmp(addressBook->contacts[i].phone,phone) == 0)       //Number should be unique
                valid = 0;
        }
        if(!valid)
        {
            attempts--;
            printf("Entered number is not valid,");     //Give chances to enter valid number
        }
    } while(!valid && attempts > 0);    
    if(attempts == 0)
    {
        printf("Failed to enter valid phone number.\n");
    }
    strcpy(addressBook->contacts[index].phone,phone);       //Compare and print details
    printf("\nName :%s",addressBook->contacts[index].name);
    printf("\nphone No :%s",addressBook->contacts[index].phone);
    printf("\nEmail Id :%s\n",addressBook->contacts[index].email);
    return 0;
}

int edit_by_email(AddressBook *addressBook,int index)       //Function to edit by emial
{
    char email[20];
    int valid = 1;
    int attempts =3;
    do
    {
        valid = 1;
        int atCount = 0, atPos = -1, dotPos = -1;
        printf("Enter email id: ");                     //Take email from user
        scanf(" %[^\n]", email);                        //Read email from user
        for (int i = 0;email[i]; i++)                   //Validate email id
        {
            if (email[i] >= 'A' && email[i] <= 'Z')
            {
                valid = 0;
                break;
            }
            if (email[i] == '@')
            {
                atCount++;
                atPos = i;
            }
            if (email[i] == '.')
            {
                dotPos = i;
            }
        }
        if (atCount != 1 || atPos == 0 || dotPos < atPos + 2)
            valid = 0;
        for (int i = 0; i < addressBook->contactCount && valid; i++)
        {
            if (strcmp(addressBook->contacts[i].email,email) == 0)      //Email id should be unique
                valid = 0;
        }
        if (!valid)
        {
            attempts--;
            printf("Entered email is not valid,");          //Give chances to enter valid email id
        }
    } while (!valid && attempts > 0);
    if (attempts == 0)
    {
        printf("Failed to enter valid email.\n");
    }
    strcpy(addressBook->contacts[index].email,email);           //Compare and print the details
    printf("\nName :%s",addressBook->contacts[index].name);
    printf("\nphone No :%s",addressBook->contacts[index].phone);
    printf("\nEmail Id :%s\n",addressBook->contacts[index].email);
    return 0;
}
 
//Function to delete the contact 
void deleteContact(AddressBook *addressBook)
{
	//Define the logic for deletecontact 
    int index=0;
    searchContact(addressBook);                 //Call search funtion to delete contact
    if (index == -1)
    {
        printf("Contact not found\n");
    }
    else
    {
        char ch;
        printf("Are you sure to delete contact? (Y/N):");       //Ask permission to delete contact
        scanf(" %c",&ch);
        if(ch == 'Y' || ch == 'y')
        {
            for(int i=index;i<addressBook->contactCount-1;i++)
            {
                addressBook->contacts[i] = addressBook->contacts[i+1];
            }
            addressBook->contactCount--;                            //Decrement the contact count 
            printf("Contact deleted sucessfully\n");
        }  
        else
        {
            printf("Delete cancelled\n");
        } 
    }
    return; 
} 



    
   

